package com.example.project.utils;

public class Constants {
   public static String KEY_MSP_POS = "allPositions3";
    public static String KEY_MSP = "user3";
    public static String KEY_MSP_ALL = "allUsers3";
    public static String MANAGER_ID = "313230088";
    public static String KEY_FORM_DATA = "formdata";

}
